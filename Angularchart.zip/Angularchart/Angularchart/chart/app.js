// Creating and initializing angular module
var csvApp = angular.module('csvApp', ['ngRoute']);

// Route configuration
csvApp.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
  $routeProvider.when('/csv', {
    templateUrl: 'views/csv.html',
    controller: 'CsvController'
  }).when('/', {
    redirectTo: '/csv'
  }).otherwise({
    redirectTo: '/csv'
  });

  
  $locationProvider.hashPrefix('');
}]);


csvApp.constant('SERVER_INFO', {
 
});


csvApp.controller('AppController', ['$scope', function ($scope) {

  
  $scope.activeMenu = 'Upload';

  $scope.setActiveMenu = function (menu) {
    $scope.activeMenu = menu;
  };
  
}]);


csvApp.service('AppService', ['SERVER_INFO', function (SERVER_INFO) {

  
    var getServerUrl = function (url) {
        debugger;
    return '';
  };

  return {
    getServerUrl: getServerUrl
  };

}]);

