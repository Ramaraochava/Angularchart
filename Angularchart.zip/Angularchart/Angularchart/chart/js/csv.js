
csvApp.controller('CsvController', ['$scope', 'CsvService', function ($scope, CsvService) {

    
    var $seriesChart = $("#seriesChart");
    
    var $seriesGrid = $('#seriesGrid');

    
    $scope.parseCsv = function (event) {
        var files = event.files;
        var fileName = files[0].name;
        var fileType = fileName.split('.').pop().toLowerCase();
        if (fileType !== 'csv') {
            alert('Please select a file of type *.csv.');
            
            $("#csvFile").replaceWith($("#csvFile").val('').clone(true));
            return;
        }
        var reader = new FileReader();
        reader.onload = function (event) {
            debugger;
            var content = event.target.result;
            content = convertToJson(content);
            CsvService.saveDataPoints(content, cbSaveData);
        };
        reader.readAsText(files[0]);
    };

   
    function convertToJson(content) {
        var rows = content.split('\n');
        var output = [];
        for (var i = 0, len = rows.length; i < len; i++) {
            var cells = rows[i].split(',');
            output[i] = {
                'name': cells[0],
                'series': []
            };
            for (var j = 1, len2 = cells.length; j < len2 - 1; j++) {
                var cell = cells[j].split('|');
                output[i].series.push([+cell[0], +cell[1]])
            }
        }
        return output;
    }

    
    function cbSaveData(response) {
        debugger;
        var data = response.config.data;
        var table = $seriesGrid.DataTable({
            data: data,
            searching: false,
            columns: [{
                'title': 'Series name',
                'data': "name"
            },   {
                'data': null,
                'defaultContent': "<button class='btn-sm btn-primary'>Generate chart</button>"
            }]
        });

        $seriesGrid.find('tbody').on('click', 'button', function () {
            debugger;
            var data = table.row($(this).parents('tr')).data();
            CsvService.getDataPoints(data, renderChart);
        });
    }

   
    function renderChart(response) {
        debugger;
        var data = response.config.params.id;
        var series = data.series;
        $.plot($seriesChart, [{
            data: series,
            lines: {
                show: true
            }
        }]);
    }
}]);


csvApp.service('CsvService', ['$http', 'AppService', function ($http, AppService) {

   
    var saveDataPoints = function (content, cb) {
        $http({
            method: 'POST',
            url: '',
            data: content
        }).then(function success(response) {
            cb(response);
        }, function error(response) {
            cb(response);
        });
    };

    
    var getDataPoints = function (id, cb) {
        $http({
            method: 'GET',
            url: '',
            params: {
                id: id
            }
        }).then(function success(response) {
            cb(response);
        }, function error(response) {
            cb(response);
        });
    };

    return {
        saveDataPoints: saveDataPoints,
        getDataPoints: getDataPoints
    };
}]);